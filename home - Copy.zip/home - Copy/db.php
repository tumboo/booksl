Database 'project_book'


CREATE TABLE books_info(
    id int not null AUTO_INCREMENT,
    name varchar(255) not null,
    writer varchar(255) not null,
    edition varchar(255) not null,
    priceN int(255) not null,
    priceW int(255) not null,
    level_term varchar (255) not null,
    
    
    PRIMARY KEY (id)
    );

    CREATE TABLE orders_info(
    id int not null AUTO_INCREMENT,
    name varchar (255) not null,
    address varchar(255) not null,
    mobile_no int (255) not null,
    level_term varchar (255) not null,
    
    PRIMARY KEY (id)
    );



    edit//tble
    CREATE TABLE orders_info(
    id int not null AUTO_INCREMENT,
    name varchar (255) not null,
    address varchar(255) not null,
    mobile_no int (255) not null,
    level_term varchar (255) not null,
    catagories varchar (255) not null,
    extra1 varchar(255) not null,
    extra2 varchar(255) not null,
    extra3 varchar(255) not null,
    
    PRIMARY KEY (id)
    );