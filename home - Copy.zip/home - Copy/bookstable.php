<?php 
$conn = mysqli_connect("localhost","root","","project_book");
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
</html>

<table align='left' width='100%' height='60%' style=color:black style='font-size:40px'>

	<tr>
		<td colspan='20' align='center'>
		<h1>Viewing the all records.</h1></td>
		</tr>
		
		<tr>
			<th>Serial</th>
			<th>Books Name</th>
			<th>Writers Name</th>
			<th>Edition</th>
			<th>PriceN</th>
			<th>PriceW</th>
			<th>Level/Term</th>
		</tr>
	
	<tr>
	
<?php

$conn = mysqli_connect("localhost","root","","project_book");

$que = "select * from books_info";
$run = mysqli_query($conn,$que);

$i=1;

while ($row = mysqli_fetch_array($run))
{
		$id = $row['id'];
		$name = $row[1];
		$writer = $row[2];
		$edition = $row[3];
		$priceN = $row[4];
		$priceW = $row[5];
		$level_term = $row[6];

?>
	<tr>
		<td><?php echo $i; $i++; ?></td>
		<td><?php echo $name ; ?> </td>
		<td><?php echo $writer ; ?> </td>
		<td><?php echo $edition ; ?> </td>
		
      
		<td><?php echo $priceN ; ?> <input type="radio" name="optradio">Option 1</td>
			
		<td><?php echo $priceW ; ?> <input required type="radio" name="priceN" value="Present"> </td>
		
		<td><?php echo $level_term ; ?> </td>
	</tr>

</tr>

<?php } ?>	

</table>
<form>
		<a href="class1.php" class="btn btn-primary">Back</a>
 </form>