<!DOCTYPE html>
<html>
<head>
	<title>CSE Student</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
	<form action="cse1.php" method="post">
		
		Name: <input type="text" name="name" required/>
		<br>
		Address: <input type="text" name="address" required/>
		<br>
		Mobile: <input type="number" name="mobile_no" required/>
		<br>
		Level/Term: <select name="level_term" required>

					<option value='null'>Level/Term</option>
					<option value=11>Level-1/Term-I</option>
					<option value=12>Level-1/Term-II</option>
					<option value=21>Level-2/Term-I</option>
					<option value=22>Level-2/Term-II</option>
					<option value=31>Level-3/Term-I</option>
					<option value=32>Level-3/Term-II</option>
					<option value=41>Level-4/Term-I</option>
					<option value=42>Level-4/Term-II</option>
					
				</select>
				<br>

		<input type="submit" name="Submit" class="btn">

	</form>

</body>
</html>

