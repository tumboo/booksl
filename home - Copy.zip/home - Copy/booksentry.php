<!DOCTYPE html>
<html>
<head>
	<title>CSE Student</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
	<form action="booksentry.php" method="post">
		
		Name: <input type="text" name="name" required/>
		<br>
		writer: <input type="text" name="writer" required/>
		<br>
		edition: <input type="text" name="edition" required/>
		<br>
		priceN: <input type="text" name="priceN" required/>
		<br>
		priceW: <input type="text" name="priceW" required/>
		<br>
		Level/Term: <select name="level_term" required>

					<option value='null'>Level/Term</option>
					<option value=11>Level-1/Term-I</option>
					<option value=12>Level-1/Term-II</option>
					<option value=21>Level-2/Term-I</option>
					<option value=22>Level-2/Term-II</option>
					<option value=31>Level-3/Term-I</option>
					<option value=32>Level-3/Term-II</option>
					<option value=41>Level-4/Term-I</option>
					<option value=42>Level-4/Term-II</option>
					
				</select>
				<br>

		<input type="submit" name="Submit">

	</form>

</body>
</html>

<?php 
$conn = mysqli_connect("localhost", "root", "","project_book");

if(isset($_POST['Submit']))
{
	$name = $_POST['name'];
	$writer = $_POST['writer'];
	$edition = $_POST['edition'];
	$priceN = $_POST['priceN'];
	$priceW = $_POST['priceW'];
	$level_term = $_POST['level_term'];
	

	$query = "insert into books_info (name,writer,edition,priceN,priceW,level_term) values ('$name','$writer','$edition','$priceN','$priceW','$level_term')";

	if($run=mysqli_query($conn,$query))
		{
			echo "done";
		}
		else
		{
			echo "NOT";
		}

}

?>

