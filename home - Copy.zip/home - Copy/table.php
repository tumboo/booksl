<?php 
$conn = mysqli_connect("localhost","root","","project_book");
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body>


<div class="panel panel-default container">

	<div class="panel-heading">

		<h1 style="text-align: center;">Attendance Mangement Syatem</h1>

	</div>

<form method="post">
	<table class="table">

		<thead>
			
		<tr>
			<th>Serial</th>
			<th>Books Name</th>
			<th>Writers Name</th>
			<th>Edition</th>
			<th>PriceN</th>
			<th>PriceW</th>
			<th>Level/Term</th>
		</tr>	

		</thead>
<tbody>

<?php 
		
			$query="select * from books_info";
			$result=$conn->query($query);

			while($show=$result->fetch_assoc()) {
				$id = $row['id'];
		$name = $row[1];
		$writer = $row[2];
		$edition = $row[3];
		$priceN = $row[4];
		$priceW = $row[5];
		$level_term = $row[6];

?>
		<tr>
			<td><?php echo $i; $i++; ?></td>
			<td><?php echo $name ; ?> </td>
			<td><?php echo $writer ; ?> </td>
			<td><?php echo $edition ; ?> </td>
		
			<td>
					
				PriceN <?php echo $priceN ; ?><input required type="radio" name="attendance[<?php echo $show['u_id'] ?>]" value="Present"> 
				PriceW <?php echo $priceW ; ?><input required type="radio" name="attendance[<?php echo $show['u_id']; ?>]" value="Absent">

			</td>

			<td><?php echo $level_term ; ?> </td>


			</tr>
<?php } ?>


</tbody>
</table>
</form>
</div>
</body></html>

