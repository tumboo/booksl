<!DOCTYPE html>
<html>
<title>W3.CSS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>

<div class="w3-bar w3-black">
  <a class="w3-bar-item w3-button">Home</a>
   <div class="w3-dropdown-hover">
    <button class="w3-button w3-black">Dept</button>
    <div class="w3-dropdown-content w3-bar-block w3-border">
  <a href="ipe.php" class="w3-bar-item w3-button">Ipe</a>
  <a href="cse.php" class="w3-bar-item w3-button">CSE</a>
  <a href="me.php" class="w3-bar-item w3-button">ME</a>
</div>
</div>
</div>

</body>
</html>
